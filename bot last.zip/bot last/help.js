
const help = (prefix) ={
                return'
┏━━━━━━━━®¥ * MENU BOT * ¥®━━━━━━━━┓
┣━⊱ ❉ {prefix} #tts id 
┣━⊱ ❉ {prefix} #block [@]
┣━⊱ ❉ {prefix} #unblock[@]
┣━⊱ ❉ {prefix} #randomanime
┣━⊱ ❉ {prefix} #nekonime
┣━⊱ ❉ {prefix} #pokemon
┣━⊱ ❉ {prefix} #bucin
┣━⊱ ❉ {prefix} #sticker
┣━⊱ ❉ {prefix} #kick[@]
┣━⊱ ❉ {prefix} #add[nomer]
┣━⊱ ❉ {prefix} #setprefix
┣━⊱ ❉ {prefix} #group [buka/tutup]
┣━━━━━━━━━━━━━━━━━━━
┃[*BOT BY FATUR AND WULAN*]
┗━━━━━━━━━━━━━━━━━━━

exporst.help=help