const donasi = () => { 
	return `       
┏━━━━━━━━━━━━━━━━━━━━
┃          𝗗𝗢𝗡𝗔𝗦𝗜  
┣━━━━━━━━━━━━━━━━━━━━
┣━⊱ 𝗗𝗢𝗡𝗔𝗦𝗜 𝗕𝗢𝗦𝗤𝗨𝗘 ❉⊰━━✿
┃  
┣━⊱ *DANA*
┣⊱ 0821-1848-4363
┣━⊱ *PULSA*
┣⊱ 0821-1848-4363
┃
┣━━━━━━━━━━━━━━━━━━━━
┃  *BOT BY FATUR AND WULAN*
┗━━━━━━━━━━━━━━━━━━━━`
}

exports.donasi = donasi
jangan di ubah 